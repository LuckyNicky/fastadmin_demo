<?php

return array (
  0 => 
  array (
    'name' => 'key',
    'title' => '应用key',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'LTAIOyqt0v87YPFg',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'secret',
    'title' => '密钥secret',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => 'NFztxkzQ1CPTUf0VxmgBOxyEqEfyD3',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  2 => 
  array (
    'name' => 'sign',
    'title' => '签名',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => '易卡租车',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  3 => 
  array (
    'name' => 'template',
    'title' => '短信模板',
    'type' => 'array',
    'content' => 
    array (
    ),
    'value' => 
    array (
      'register' => 'SMS_114000000',
      'resetpwd' => 'SMS_114000000',
      'changepwd' => 'SMS_114000000',
      'profile' => 'SMS_114000000',
      'user_code' => 'SMS_153135083',
    ),
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
