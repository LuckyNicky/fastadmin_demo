<?php

return [
    'Resource title' => '资源标题',
    'Event key'      => '事件标识',
    'Text'           => '文本',
    'App'            => '应用',
];
