<?php
return [
    'Channel_id'  => '栏目',
    'Tags'        => '标签',
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Upload'      => '上传',
    'Image'       => '缩略图'





];