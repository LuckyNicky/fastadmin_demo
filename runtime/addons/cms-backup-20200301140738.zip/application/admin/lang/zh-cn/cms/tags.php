<?php

return [
    'Name'     => '标签名称',
    'Archives' => '文档ID集合',
    'Nums'     => '文档数量'
];
