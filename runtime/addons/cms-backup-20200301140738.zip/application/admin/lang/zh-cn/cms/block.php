<?php

return [
    'Type'       => '类型',
    'Name'       => '名称',
    'Title'      => '标题',
    'Image'      => '图片',
    'Url'        => '链接',
    'Content'    => '内容',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
