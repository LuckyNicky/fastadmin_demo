<?php

return [
    'Id'                              => 'ID',
    'Category_id'                     => '分类ID',
    'Type'                            => '类型',
    'Title'                           => '标题',
    'Keywords'                        => '关键字',
    'Description'                     => '描述',
    'Flag'                            => '标志',
    'Image'                           => '图片',
    'Content'                         => '内容',
    'Icon'                            => '图标',
    'Views'                           => '点击',
    'Comments'                        => '评论',
    'Diyname'                         => '自定义URL名称',
    'Showtpl'                         => '视图模板',
    'Createtime'                      => '创建时间',
    'Updatetime'                      => '更新时间',
    'Check content is legal'          => '检查内容是否有违禁词',
    'Get the keyword and description' => '提取关键字和描述',
    'The data already exist'          => '已经存在',
    'Weigh'                           => '权重',
    'Select'                          => '选择',
    'Status'                          => '状态'
];
